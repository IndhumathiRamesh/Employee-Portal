import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
  
})
export class EmployeeRegisterComponent implements OnInit {
myform!:FormGroup;
ctc:any;
pf:any;
esi:any;
doj:any;
experience:any;
model:any;

  constructor(private fb:FormBuilder,public service:ServiceService) { }

  ngOnInit(): void {
    this.myform=this.fb.group({
     
        employeeName: this.fb.control('', [Validators.required,Validators.pattern('^[a-zA-Z .]+$')]),
        ctcPerYear: this.fb.control('', [Validators.required,Validators.pattern('^[0-9]+$')]),
        gender: this.fb.control('', Validators.required),
        providentFund: this.fb.control('', [Validators.required,Validators.pattern('^[0-9]+$')]),
        dateOfJoining: this.fb.control('', Validators.required),
        employeeStateInsurance: this.fb.control('', Validators.required),
        designation: this.fb.control('', Validators.required),
        experience: this.fb.control(''),
      })  
  }

 ctcCalculation() {
   var ctc = this.ctc;console.log("ctc:" + ctc)
    var BP = (40 / 100) * ctc; console.log("BP :" + BP);
    var totalPF = (12 / 100) * BP; console.log("totalPF:" + totalPF);
    var employeeesi = (0.75 / 100) * ctc; console.log("employeeesi:" + employeeesi)
    var employeresi = (3.25 / 100) * ctc; console.log("employeresi:" + employeresi)
    var totalESI = employeeesi + employeresi; console.log("totalESI:" + totalESI);
    this.pf = totalPF;
    this.esi= totalESI;
}

experienceCalculation(){
  var doj = this.doj;
  if(doj){
     const convertExperience = new Date(doj);
     const timeDiff = Math.abs(Date.now() - convertExperience.getTime());
     this.experience = Math.floor((timeDiff / (1000 * 3600 * 24))/365);
     console.log(this.experience)
    }
    console.log(doj);
    console.log(this.experience)
}
onsubmit(){
  console.log(this.myform.value);
  this.service.addPerson(this.myform.value);
  this.myform.reset();
}


}


