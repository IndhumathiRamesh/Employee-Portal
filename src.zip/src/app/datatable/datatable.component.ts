import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ServiceService } from '../service.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.css']
})
export class DatatableComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  allUsers: any = [];
  httpClient: any;
  serviceUrl: string;
  dateBefore: any;
  dateAfter: any;
  selectoption: any;
  url: any;
  ctcValue: any
  expValue: any
  closeResult!: string;

  constructor(private service: ServiceService, public http: HttpClient, private modalService: NgbModal) {
    this.serviceUrl = "http://localhost:8080/employee/delete"
  }

  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      lengthMenu: [
        [5, 25, 50, 100, 200, -1],
        [5, 25, 50, 100, 200, "Show All"]
      ],
    }
    this.getall();

  }
  getall(): void {
    this.http.get('http://localhost:8080/employee/getall').subscribe((response: any) => {
      this.allUsers = response;
      console.log(this.allUsers)
      this.dtTrigger.next(0);
    });
  }


  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }


  filter(): void {
    console.log(this.dateAfter)
    console.log(this.selectoption)
    if (this.selectoption == "Value-2") {
      this.url = "http://localhost:8080/employee/filter/ctc?ctcValue=" + this.ctcValue;
    }
    else if (this.selectoption == "Value-3") {
      this.url = "http://localhost:8080/employee/filter/exp?expValue=" + this.expValue;
    }
    else if (this.selectoption == "Value-1") {
      this.url = "http://localhost:8080/employee/filter?dateBefore=" + this.dateBefore + "&dateAfter=" + this.dateAfter;
      if (this.dateAfter == "" && this.dateBefore == "") {
        this.getall();
      }
    }
    this.http.get(this.url).subscribe((response: any) => {
      this.allUsers = response;
      console.log(this.allUsers)
      $("#datatable").DataTable().destroy();
      this.dtTrigger.next(0);
    });;
  }


  onDelete(id: number) {
    this.service.deleteUser(id);
    console.log(id)
    $("#datatable").DataTable().destroy();
    this.getall();
  }


  open(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}