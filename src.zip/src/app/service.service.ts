import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';



@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  public FormData: any;
  url: string;
  status!: string;
  errorMessage: any;
  data:any;

  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:8080/employee"
  }
  getFormData(data: any) {
    this.FormData = data;
    console.log(this.FormData)
  }


  displayData() {
    this.httpClient.get('http://localhost:8080/employee/getall');
  }

  addPerson(postData: Object) {
    let endPoints = "/add"
    this.httpClient.post(this.url + endPoints, postData).subscribe(data => {
    console.log(data);
    });

  }
  deleteUser(id:number){
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: {
        "employeeId":id
      },
    };
    return this.httpClient.delete('http://localhost:8080/employee/delete',options).subscribe(
      function(error) {
      console.log("Error happened" + error)
    },
      function() {
      console.log("successfully deleted")
    });  
    
  }}


