package com.example.springboot.daoimpl;

import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import com.example.springboot.dao.EmployeeDao;
import com.example.springboot.model.EmployeeDetail;

	
	@Repository
	public class EmployeeDaoImpl implements EmployeeDao{
		
		 @Autowired
		  private JdbcTemplate jdbcTemplate;
		

		private static String Insert_Sql = "INSERT INTO `employee_details` ("
				
				+ "employee_name,"
				+ "gender,"
				+ "date_of_joining,"
				+ "designation,"
				+ "experience,"
				+ "ctc_per_year,"
				+ "provident_fund,"
				+ "employee_state_insurance)"
			    + " VALUES(?,?,?,?,?,?,?,?)";
		 
		
		private static String Update_Sql = "UPDATE `employee_details` SET "
				+ "employee_name = ?,"
				+ "gender = ?,"
				+ "date_of_joining = ?,"
				+ "designation= ?,"
				+ "ctc_per_year = ?,"
				+ "provident_fund = ?,"
				+ "employee_state_insurance = ?"
			    + "where `employee_id` = ? ";
		
		
		private static String List_Sql ="SELECT * FROM employee_details order By employee_id desc";
		
//		private static String Filter_Sql="SELECT * FROM `employee_details` WHERE (date_of_joining BETWEEN 'start_date= ?' AND 'end_date= ?')";
	//	private static String Filter_Sql= "select date_of_joining from employee_details date_of_joining where date_of_joining.dateCompte between :x and :y";
		
		
		
		@Override
		public long addEmployeeDetail(EmployeeDetail employeeDetail) {
			 KeyHolder keyHolder = new GeneratedKeyHolder();
			    jdbcTemplate.update(connection -> {
			      PreparedStatement ps = connection.prepareStatement(Insert_Sql, java.sql.Statement.RETURN_GENERATED_KEYS);
			      ps.setString(1, employeeDetail.getEmployeeName());
			      ps.setString(2, employeeDetail.getGender());
			      ps.setString(3, employeeDetail.getDateOfJoining());
			      ps.setString(4, employeeDetail.getDesignation());
			      ps.setInt(5, employeeDetail.getExperience());
			      ps.setDouble(6, employeeDetail.getCtcPerYear());
			      ps.setDouble(7, employeeDetail.getProvidentFund());
			      ps.setDouble(8,employeeDetail.getEmployeeStateInsurance());
			      return ps;
			    }, keyHolder);
			    return keyHolder.getKey().longValue();
		}

		public int updateEmployeeDetail(EmployeeDetail employeeDetail) {
			return jdbcTemplate.update(Update_Sql,
					employeeDetail.getEmployeeName(),
					employeeDetail.getGender(),
					employeeDetail.getDateOfJoining(),
					employeeDetail.getDesignation(),
					employeeDetail.getCtcPerYear(),
					employeeDetail.getProvidentFund(),
					employeeDetail.getEmployeeStateInsurance(),
					employeeDetail.getEmployeeId());
		}  
		@Override
		public String deleteEmployeeDetail(EmployeeDetail employeeDetail) {
			int result=0;
			 String res="failure";
			 
				 try {
					 result=jdbcTemplate.update("DELETE FROM employee_details WHERE employee_id=?", 
								employeeDetail.getEmployeeId());
					 if(result>0) {
						 res="{\"status\":success ,\"message\":deleted successfully}";
					 }else {
						 res="{status:'failure' ,message:'no data found'}"; 
					 }
				 }catch(Exception e) {
					 res="{ status:failure ,  message:"+e.toString()+"}";
//					 "{\"status\": success ,\"message\": Leave settings update successful }"
			 }
			 return res;
		}
		@Override
		public List<EmployeeDetail> getAllEmployeeDetail() {
			
			return jdbcTemplate.query(List_Sql, new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
			
		}
		@Override
		public List<EmployeeDetail> filterEmployeeDetail(String dateBefore,String dateAfter) {
			String Filter_Sql="SELECT * FROM employee_details WHERE date_of_joining BETWEEN '"+dateBefore+"' AND '"+dateAfter+"'";
			System.out.println(Filter_Sql);
			List<EmployeeDetail> emp=jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
			return jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
//			public List<EmployeeDetail> filterEmployee(@Param("x")LocalDate dateBefore, @Param("y")LocalDate dateAfter); 
//			System.out.println(emp.toString());
//			return null;
		}

		@Override
		public List<EmployeeDetail> filterEmployeeDetail(String ctcValue) {
			String Filter_Sql="SELECT * FROM employee_details WHERE ctc_per_year = '"+ctcValue+"'";
			System.out.println(Filter_Sql);
			List<EmployeeDetail> emp=jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
			return jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
		
		}
		@Override
		public List<EmployeeDetail> filterEmployeeDetails(String expValue) {
			String Filter_Sql="SELECT * FROM employee_details WHERE experience = '"+expValue+"'";
			System.out.println(Filter_Sql);
			List<EmployeeDetail> emp=jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
			return jdbcTemplate.query(Filter_Sql,new BeanPropertyRowMapper<EmployeeDetail>(EmployeeDetail.class));
		
		}
		}
			
