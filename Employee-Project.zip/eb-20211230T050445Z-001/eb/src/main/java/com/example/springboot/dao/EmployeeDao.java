package com.example.springboot.dao;

import java.time.LocalDate;
import java.util.List;

import com.example.springboot.model.EmployeeDetail;



public interface EmployeeDao {
	
	long addEmployeeDetail(EmployeeDetail employeeDetail);
	
	int updateEmployeeDetail(EmployeeDetail employeeDetail);

	
	List<EmployeeDetail> getAllEmployeeDetail();	
	


	List<EmployeeDetail> filterEmployeeDetail(String dateBefore, String dateAfter);
	List<EmployeeDetail> filterEmployeeDetail(String ctcValue);
	List<EmployeeDetail> filterEmployeeDetails(String expValue);

	String deleteEmployeeDetail(EmployeeDetail employeeDetail);




}