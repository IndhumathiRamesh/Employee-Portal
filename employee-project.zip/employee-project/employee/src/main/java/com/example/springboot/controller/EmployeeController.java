package com.example.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.model.EmployeeDetail;
import com.example.springboot.service.EmployeeService;

@RequestMapping("/employee")

@RestController
@CrossOrigin(origins="*",allowedHeaders="*")
public class EmployeeController{
	@Autowired
	private EmployeeService employeeService;
	@GetMapping("/getall")                                                                                                                                                                                                                                                                                                                                                                                                                                
	public List <EmployeeDetail>getAllEmployee(EmployeeDetail employeeDetail){
		List<EmployeeDetail> employees=new ArrayList<EmployeeDetail>();
		employees=employeeService.getAllEmployee();
		return employees;
	}
	@GetMapping("/filter")    
	public List<EmployeeDetail> filterEmployeeDetail(@RequestParam("dateBefore") String dateBefore, 
	        @RequestParam("dateAfter") String dateAfter){
		System.out.println(dateBefore +" "+ dateAfter);
//       return employeeService.filterEmployee(dateBefore,dateAfter);
		List<EmployeeDetail> empd=employeeService.filterEmployee(dateBefore,dateAfter);
//		System.out.println(empd.toString());
return empd;
		
	}
	@GetMapping("/filter/ctc")    
	public List<EmployeeDetail> filterEmployeeDetail(@RequestParam("ctcValue") String ctcValue){
		System.out.println(ctcValue);
//       return employeeService.filterEmployee(dateBefore,dateAfter);
		List<EmployeeDetail> ctc=employeeService.filterCtc(ctcValue);
//		System.out.println(empd.toString());
return ctc;
		
	}
	@GetMapping("/filter/exp")    
	public List<EmployeeDetail> filterEmployeeDetails(@RequestParam("expValue") String expValue){
		System.out.println(expValue);
//       return employeeService.filterEmployee(dateBefore,dateAfter);
		List<EmployeeDetail> ctc=employeeService.filterExp(expValue);
//		System.out.println(empd.toString());
return ctc;
		
	}
	
	
	

	 
	 
	 
	 @PostMapping("/update")
	    public void updateEmployeeDetail(@RequestBody EmployeeDetail employeeDetail) {
	        employeeService.updateEmployeeService(employeeDetail);
	    }
	 
	 @DeleteMapping("/delete")
	    public ResponseEntity<String> deleteEmployeeDetail(@RequestBody EmployeeDetail employeeDetail) {
		 System.out.println(employeeDetail.getEmployeeId());
	        String response=employeeService.deleteEmployeeService(employeeDetail);
	        System.out.println(response);
	        return new ResponseEntity<>(response,HttpStatus.OK);
	        
	    }
	 @PostMapping("/add")
	 @ResponseStatus(value = HttpStatus.CREATED, reason = "Employee Created")
//	 public ResponseEntity<String> statusWithResponseEntity() {
//		    return ResponseEntity.status(HttpStatus.ACCEPTED).body("Done");
//		}
	    public void createEmployeeDetail(@RequestBody EmployeeDetail employeeDetail) {
//		 System.out.println(employeeDetail.getEmployeeName());
	        employeeService.addEmployeeService(employeeDetail);
	    }
	 

	 

}
