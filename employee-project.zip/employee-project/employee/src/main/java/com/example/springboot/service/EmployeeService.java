package com.example.springboot.service;

import java.time.LocalDate;
import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.dao.EmployeeDao;
import com.example.springboot.model.EmployeeDetail;

@Service
public class EmployeeService {
	
	private static final LocalDate LocalDate = null;
	@Autowired
	EmployeeDao employeeDao;
	
	public void addEmployeeService(EmployeeDetail employeeDetail) {
		employeeDao.addEmployeeDetail(employeeDetail);
		
	}
	public void updateEmployeeService(EmployeeDetail employeeDetail) {
		employeeDao.updateEmployeeDetail(employeeDetail);
	}
    
	public String deleteEmployeeService(EmployeeDetail employeeDetail) {
		return employeeDao.deleteEmployeeDetail(employeeDetail);
	}
    
	 public List<EmployeeDetail> getAllEmployee() {
	      return employeeDao.getAllEmployeeDetail();
	      
	   }
	 public List<EmployeeDetail> filterEmployee(String dateBefore,String dateAfter) {
	      return employeeDao.filterEmployeeDetail(dateBefore,dateAfter);
	   }
	 public List<EmployeeDetail> filterCtc(String ctcValue) {
	      return employeeDao.filterEmployeeDetail(ctcValue);
	   }
	 public List<EmployeeDetail> filterExp(String expValue) {
	      return employeeDao.filterEmployeeDetails(expValue);
	   }
	 
//	 public Response createUser(EmployeeDetail employeeDetail) {
//		    if ( employeeDetail== null) {
//		        throw new ResourceNotFoundException("Empty", "Missing Data Exception");
//		    } else {
////		    	EmployeeDetail employeeDetail1= employeeDao.save(employeeDetail1);
//		        return new Response();
//		    }
//		}
//	 
//	 public List<EmployeeDetail> filterEmployee() {
//		 return employeeDao.filterEmployeeDetail();
//	}
//	public List<EmployeeDetail> filterCtc(String ctcValue) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}