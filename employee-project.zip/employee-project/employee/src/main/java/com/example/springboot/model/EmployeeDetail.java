package com.example.springboot.model;

import java.time.LocalDate;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_details")
public class EmployeeDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	

	
	private Integer EmployeeId;
	
	private String EmployeeName;
	
	private String Gender;
	
	private String DateOfJoining;
	
	private String Designation;
	
	private Integer Experience;
	
	private Double CtcPerYear;
	
	private Double ProvidentFund;
	
	private Double EmployeeStateInsurance;
	

	private Double Tax;
	
	private Double TakeHomePay;
	
	
//	class Response {
//
//	    private String EmployeeName;
//	    private String statusMessage;
//
//	    public Response(String EmployeeName) {
//	        this.EmployeeName = EmployeeName;
//	        this.statusMessage = "Customer Created Successfully";
//	    }
//
//		public String getEmployeeName() {
//			return EmployeeName;
//		}
//
//		public void setEmployeeName(String employeeName) {
//			EmployeeName = employeeName;
//		}
//
//		public String getStatusMessage() {
//			return statusMessage;
//		}
//
//		public void setStatusMessage(String statusMessage) {
//			this.statusMessage = statusMessage;
//		}
//
//	   
//	}
//	
	
	public Integer getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		EmployeeId = employeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getDateOfJoining() {
		return DateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		DateOfJoining = dateOfJoining;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public Integer getExperience() {
		return Experience;
	}

	public void setExperience(Integer experience) {
		Experience = experience;
	}

	public Double getCtcPerYear() {
		return CtcPerYear;
	}

	public void setCtcPerYear(Double ctcPerYear) {
		CtcPerYear = ctcPerYear;
	}

	public Double getProvidentFund() {
		return ProvidentFund;
	}

	public void setProvidentFund(Double providentFund) {
		ProvidentFund = providentFund;
	}

	public Double getEmployeeStateInsurance() {
		return EmployeeStateInsurance;
	}

	public void setEmployeeStateInsurance(Double employeeStateInsurance) {
		EmployeeStateInsurance = employeeStateInsurance;
	}

	public Double getTax() {
		return Tax;
	}

	public void setTax(Double tax) {
		Tax = tax;
	}

	public Double getTakeHomePay() {
		return TakeHomePay;
	}

	public void setTakeHomePay(Double takeHomePay) {
		TakeHomePay = takeHomePay;
	}



	

//	@Override
//	public String toString() {
//		return "Employee [employee_id=" + employee_id + ", employee_name=" + employee_name + ", gender=" + gender
//				+ ", date_of_joining=" + date_of_joining + ", designation=" + designation + ", experience=" + experience
//				+ ", ctc_per_year=" + ctc_per_year + ", provident_fund=" + provident_fund
//				+ ", employee_state_insurance=" + employee_state_insurance + ", tax=" + tax + ", take_home_pay="
//				+ take_home_pay + "]";
//	}


}